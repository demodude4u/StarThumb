import math
import gc

from thumbyButton import buttonA, buttonB, buttonU, buttonD, buttonL, buttonR

from STGraphics import loadImpPPM, fill, blit, blitScale, blitRotate, display, update
from STContainer import Container, loadMapCSV, blitContainer
from STShading import loadShaderPPM, postShading

import perf

gc.collect()

buffer = bytearray(72*40)

shader = loadShaderPPM("/Games/DemoST1Transport/Shader.ppm")

impTiles = loadImpPPM("/Games/DemoST1Transport/TilesColor.ppm",
                      "/Games/DemoST1Transport/TilesShading.ppm")
map, mw, mh = loadMapCSV("/Games/DemoST1Transport/Map.csv")

impShipSmall = loadImpPPM("/Games/DemoST1Transport/ShipSmColor.ppm",
                          "/Games/DemoST1Transport/ShipSmShading.ppm")
impShip = loadImpPPM("/Games/DemoST1Transport/ShipColor.ppm",
                     "/Games/DemoST1Transport/ShipShading.ppm")
impShipLarge = loadImpPPM("/Games/DemoST1Transport/ShipLgColor.ppm",
                          "/Games/DemoST1Transport/ShipLgShading.ppm")

impGateSmall = loadImpPPM("/Games/DemoST1Transport/GateSmColor.ppm",
                          "/Games/DemoST1Transport/GateSmShading.ppm")
impGateH = loadImpPPM("/Games/DemoST1Transport/GateHColor.ppm",
                      "/Games/DemoST1Transport/GateHShading.ppm")
impGateV = loadImpPPM("/Games/DemoST1Transport/GateVColor.ppm",
                      "/Games/DemoST1Transport/GateVShading.ppm")

gc.collect()

# Features Not Experimented:
# - Thruster particles/animation
# - Scanner Shading
# - Control Zones (slow, scan, rotate lock)
# - Triggers
# - Gate Sequence
# - Docking Camera
# - Container Entities
# - Smooth Turning Controls (non-combat mode)
# - Glimmer
# - Signage
# - Trails

# Experiments To Implement:
# - TestAnimate
# - TestParticles
# - TestSpaceBits


class Ship:
    def __init__(self, impShip, speedMax_f3, accel_f3, dampening_f6, boost_f3, boostDelay, rotateSpeed):
        self.impShip = impShip
        self.speedMax_f3 = speedMax_f3
        self.accel_f3 = accel_f3
        self.dampening_f6 = dampening_f6
        self.boost_f3 = boost_f3
        self.boostDelay = boostDelay
        self.px_f3, self.py_f3 = 0, 0
        self.vx_f3, self.vy_f3 = 0, 0
        self.angleTarget = 0
        self.angle = 0
        self.boostFrames = 0
        self.rotateSpeed = rotateSpeed
        self.rotate = True

    @micropython.native
    def moveFrame(self, inputX_f3: int, inputY_f3: int):
        speedMax_f3 = self.speedMax_f3
        accel_f3 = self.accel_f3
        dampening_f6 = self.dampening_f6
        boost_f3 = self.boost_f3
        boostDelay = self.boostDelay
        vx_f3 = self.vx_f3
        vy_f3 = self.vy_f3
        boostFrames = self.boostFrames
        angleTarget = self.angleTarget
        angle = self.angle
        rotateSpeed = self.rotateSpeed

        if inputX_f3 > 0:
            vx_f3 += (accel_f3 * inputX_f3) >> 3
        elif inputX_f3 < 0:
            vx_f3 -= (accel_f3 * -inputX_f3) >> 3
        elif vx_f3 >= 0:
            vx_f3 = (vx_f3 * dampening_f6) >> 6
        else:
            vx_f3 = -((-vx_f3 * dampening_f6) >> 6)

        if inputY_f3 > 0:
            vy_f3 += (accel_f3 * inputY_f3) >> 3
        elif inputY_f3 < 0:
            vy_f3 -= (accel_f3 * -inputY_f3) >> 3
        elif vy_f3 >= 0:
            vy_f3 = (vy_f3 * dampening_f6) >> 6
        else:
            vy_f3 = -((-vy_f3 * dampening_f6) >> 6)

        if not inputX_f3 and not inputY_f3:
            boostFrames = 0
        if inputX_f3 and inputY_f3:
            boostFrames = 0

        if vx_f3 < -speedMax_f3:
            boostFrames += 1
            vx_f3 = -speedMax_f3 if boostFrames < boostDelay else -boost_f3
        elif vx_f3 > speedMax_f3:
            boostFrames += 1
            vx_f3 = speedMax_f3 if boostFrames < boostDelay else boost_f3

        if vy_f3 < -speedMax_f3:
            boostFrames += 1
            vy_f3 = -speedMax_f3 if boostFrames < boostDelay else -boost_f3
        elif vy_f3 > speedMax_f3:
            boostFrames += 1
            vy_f3 = speedMax_f3 if boostFrames < boostDelay else boost_f3

        if self.rotate:
            angleDiff = angleTarget - angle
            angleDiff = (angleDiff + 180) % 360 - 180
            angleDiff = max(-rotateSpeed, min(rotateSpeed, angleDiff))
            angle = (angle + angleDiff + 360) % 360

        self.px_f3 += vx_f3
        self.py_f3 += vy_f3
        self.vx_f3 = vx_f3
        self.vy_f3 = vy_f3
        self.boostFrames = boostFrames
        self.angle = angle

    @micropython.native
    def render(self, camX: int, camY: int):
        global buffer

        impShip = self.impShip
        w = impShip[1]
        h = impShip[2]
        hw = w >> 1
        hh = h >> 1
        x = (self.px_f3 >> 3) - camX - hw
        y = (self.py_f3 >> 3) - camY - hh
        blitRotate(buffer, impShip[0], self.angle, x, y, w, h, hw, hh)


station = Container(mw, mh, map, impTiles[0])
ship = Ship(impShip, speedMax_f3=2 << 3, accel_f3=1,
            dampening_f6=62, boost_f3=3 << 3, boostDelay=60, rotateSpeed=5)

camX, camY = 268, 34
ship.px_f3 = camX << 3
ship.py_f3 = camY << 3
lightAngle = 0

while True:

    if buttonA.justPressed():
        lightAngle = (lightAngle + 1) % 8
    if buttonB.justPressed():
        lightAngle = (lightAngle + 7) % 8

    # Ship Movement
    inputX_f3, inputY_f3 = 0, 0
    if buttonR.pressed():
        inputX_f3 = 8
    if buttonD.pressed():
        inputY_f3 = 8
    if buttonL.pressed():
        inputX_f3 = -8
    if buttonU.pressed():
        inputY_f3 = -8
    if inputX_f3 and inputY_f3:
        if inputX_f3 > 0:
            inputX_f3 = 5
        else:
            inputX_f3 = -5
        if inputY_f3 > 0:
            inputY_f3 = 5
        else:
            inputY_f3 = -5
    ship.moveFrame(inputX_f3, inputY_f3)
    # TODO get rid of floats
    if abs(ship.vx_f3) >= 12 or abs(ship.vy_f3) >= 12:
        ship.angleTarget = int(
            180*(math.atan2(ship.vy_f3, ship.vx_f3)/3.14159))
        ship.rotate = True
    else:
        ship.rotate = False

    camX = (ship.px_f3 >> 3) - 36 + (ship.vx_f3 >> 3)
    camY = (ship.py_f3 >> 3) - 20 + (ship.vy_f3 >> 3)

    fill(buffer, 0b00)

    blitContainer(buffer, station, -camX, -camY)
    ship.render(camX, camY)

    postShading(buffer, shader, lightAngle)
    display(buffer)
    perf.render()
    update()
