<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="Tiles" tilewidth="8" tileheight="8" tilecount="512" columns="8">
 <image source="../Shaded/Tiles.png" trans="008000" width="64" height="512"/>
</tileset>
